package it.epicode.entities.library;

public enum Periodicità {

	SETTIMANALE, 
	MENSILE, 
	SEMESTRALE
}
